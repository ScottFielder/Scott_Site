
#include <iostream>
#include <fstream>
#include "tinyxml2.h"
using namespace tinyxml2;

struct Vec3 {
	float x, y, z;
	void print() {
		printf("%f %f %f\n", x, y, z);
	}
};

struct Color4 {
	float red, green, blue, alpha;
	void print() {
		printf("%f %f %f %f\n", red, green, blue, alpha);
	}
};

void ReadManifest();

int main() {
	ReadManifest();
}
	

void ReadManifest() {
	std::cout << "ReadManifest\n";
	Color4 diffuse;
	XMLDocument doc;
	doc.LoadFile("Manifest.xml");
	bool status = doc.Error();
	if (status) {
		std::cout << doc.ErrorIDToName(doc.ErrorID()) << std::endl;
		return;
	}

	XMLElement* rootData = doc.RootElement();
	XMLElement* sceneData = rootData->FirstChildElement("Scene1");
	
	XMLElement* cameraData = sceneData->FirstChildElement("Camera");

	XMLElement* cameraLocation = cameraData->FirstChildElement("Location");

	Vec3 location;
	location.x = cameraLocation->FloatAttribute("x");
	location.y = cameraLocation->FloatAttribute("y");
	location.z = cameraLocation->FloatAttribute("z");
	location.print();

	XMLElement* orientationData = cameraData->FirstChildElement("Orientation");
	Vec3 orientation;
	orientation.x = orientationData->FloatAttribute("yaw");
	orientation.y = orientationData->FloatAttribute("pitch");
	orientation.z = orientationData->FloatAttribute("roll");
	orientation.print();
	


}
