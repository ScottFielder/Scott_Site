#include "Body.h"

Body::Body(){
	pos.x = 2.0f;
	pos.y = 12.5f;
	pos.z = 0.0f;

	vel.x = 15.0f;
	vel.y = 0.0f;
	vel.z = 0.0f;

	accel.x = 0.0f;
	accel.y = -9.81f;
	accel.z = 0.0f;

	mass = 1.0f;
}
Body::Body(Vec3 pos_) {
	pos.x = pos_.x;
	pos.y = pos_.y;
	pos.z = pos_.z;

	vel.x = 15.0f;
	vel.y = 0.0f;
	vel.z = 0.0f;

	accel.x = 0.0f;
	accel.y = -9.81f;
	accel.z = 0.0f;

	mass = 1.0f;
}

Body::~Body(){
	
}

void Body::Update(float deltaTime){
	pos.x += vel.x * deltaTime + 0.5f * accel.x * deltaTime * deltaTime;
	pos.y += vel.y * deltaTime + 0.5f * accel.y * deltaTime * deltaTime;
	pos.z += vel.z * deltaTime + 0.5f * accel.z * deltaTime * deltaTime;

	vel.x += accel.x * deltaTime;
	vel.y += accel.y * deltaTime;
	vel.z += accel.z * deltaTime;
	//std::cout << pos.y << " " << vel.y << std::endl;
	///Floor collision
	if (pos.y < 2.0f) {
		vel.y *= -1.0f;
		pos.y = 2.0f;
	}
	// roof
	if (pos.y > 15.0f) {
		vel.y *= -1.0f;
		pos.y = 15.0f;
	}
	// Right wall
	if (pos.x > 28.0f) {
		vel.x = -vel.x;
		pos.x = 28.0f;
	}
	// Left wall
	if (pos.x < 0.0f) {
		vel.x = -vel.x;
		pos.x = 0.0f;
	}
}
