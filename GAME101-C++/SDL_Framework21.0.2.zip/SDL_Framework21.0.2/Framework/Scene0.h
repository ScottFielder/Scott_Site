#ifndef SCENE0_H
#define SCENE0_H

#include "MMath.h"
#include "Scene.h"
#include <SDL.h>
#include "Body.h"

using namespace MATH;
class Scene0 : public Scene {
private:
	SDL_Window *window;
	Matrix4 projectionMatrix;
	Body* balloon1;
	Body* balloon2;
	SDL_Surface* ballImage;

	
public:
	Scene0(SDL_Window* sdlWindow);
	virtual ~Scene0();
	virtual bool OnCreate();
	virtual void OnDestroy();
	virtual void Update(const float time);
	virtual void Render();
};

#endif

