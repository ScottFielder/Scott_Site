

class Ball {
private:
	float x, y, z;
	float vx,vy,vz;
	float g;
public:
	Ball();
	~Ball();
	void Update();
};
