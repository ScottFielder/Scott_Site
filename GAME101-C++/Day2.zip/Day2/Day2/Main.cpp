#include <stdio.h>
#include "Ball.h"


int main(int argc, char* argv[]) {
	Ball balloon;
	for (int i = 0; i < 2 * 98; ++i) {
		balloon.Update();
	}
}



