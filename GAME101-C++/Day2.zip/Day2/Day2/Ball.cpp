#include <stdio.h>
#include "Ball.h"

// :: scope resolution operator
Ball::Ball() {
	printf("Hello from the the constructor\n");
	x = z = 0.0f;
	y = 12.5f; // meters
	vy = 0.0f; // m/s
	g = -9.8f; // m/s/s
}

Ball::~Ball() {
	printf("Good-bye from the the destructor\n");
	// nothing to destroy just yet
}

void Ball::Update() {
	float time = 0.0167f;// secs
	y += vy * time + 0.5f * g * time * time;
	vy += g * time;
	if (y < 0.0f) {
		vy *= -1.0f;
	}
	printf(" %f %f \n", y, vy);
}

