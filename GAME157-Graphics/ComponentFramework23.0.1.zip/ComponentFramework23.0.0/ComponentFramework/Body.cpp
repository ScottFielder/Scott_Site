#include "Body.h"
Body::Body(): pos{}, vel{}, accel{}, mass{1.0f}, mesh{nullptr},texture{nullptr} {
}

Body::~Body() {}

void Body::Update(float deltaTime) {
	/// From 1st semester physics class
	pos += vel * deltaTime + 0.5f * accel * deltaTime * deltaTime;
	vel += accel * deltaTime;
}

void Body::ApplyForce(Vec3 force) {
	accel = force / mass;
}

void Body::UpdateOrientation(float deltaTime)
{
	// Step 1
	// Find the angle we are rotating by
	float angleRadians = VMath::mag(angularVel) * deltaTime;
	// Step 2
	// Get outta here if angle is zero
	if (angleRadians < VERY_SMALL) {
		return;
	}
	// Step 3
	// Find the axis of rotation
	Vec3 axis = VMath::normalize(angularVel);
	// Step 4
	// Build a rotation quaternion
	// Thank Scott for this
	float angleDegrees = angleRadians * RADIANS_TO_DEGREES;
	Quaternion rotation = QMath::angleAxisRotation(angleDegrees, axis);
	// Step 5
	// Apply the rotation to the orientation
	// TODO: Umer has to remember is this the right way?
	orientation = rotation * orientation;
}

bool Body::OnCreate(){
	return true;
}

void Body::OnDestroy(){
}

void Body::Render() const {
}

