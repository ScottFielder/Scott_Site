#pragma once
namespace Vector{
    class Vec3
    {
    public:
        float x1,y1,z1;
    };
}

