#include <vector>
#include "MemoryMonitor.h"





struct Vec3 {
    float x, y, z;
    Vec3() {
        x = y = z = 0.0f;
    }
    
};

int main(int argc) {
    int* ptr = ::new int[1024];
    delete[] ptr;

   /* Vec3* vPtr = new Vec3();
    delete vPtr;*/
    
    ///std::unique_ptr<Vec3> v = std::make_unique<Vec3>();
  //  std::string str = "Game Engines 5 !";
    /*std::vector<Vec3> verticies;
    for (int i = 0; i < 32; ++i) {
        verticies.push_back(Vec3());
    }*/
}