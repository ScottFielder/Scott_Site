#ifndef MEMORYMONITOR_H
#define MEMORYMONITOR_H
#include <iostream>
#include <memory>

void* operator new(std::size_t numBytes) {
    std::cout << "allocating " << numBytes << " bytes of memory\n";
    return std::malloc(numBytes);
}

void operator delete(void* memoryLocation, std::size_t numBytes) {
    std::cout << "freeing " << numBytes << " bytes of memory\n";
    std::free(memoryLocation);
}



struct ArraySize{
    std::size_t numBytes;
};

void* operator new[](std::size_t numBytes) {
    std::cout << "allocating an array of " << numBytes << " bytes of memory\n";
    ArraySize* array = reinterpret_cast<ArraySize*>(std::malloc(numBytes + sizeof(ArraySize)));
    array->numBytes = numBytes;
    return array + 1;
}

void operator delete[](void* memoryLocation) {
    ArraySize* array = reinterpret_cast<ArraySize*>(memoryLocation) - 1;
    std::cout << "freeing array "<< array->numBytes << " bytes of memory\n";
    free(array);
}



#endif