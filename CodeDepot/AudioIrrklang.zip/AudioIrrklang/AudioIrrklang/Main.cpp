#include <stdio.h>
#include <irrKlang.h>
#include <chrono>
#include <thread>
using namespace irrklang;
bool isRunning;
int main() {
	char c;
	ISoundEngine* engine = createIrrKlangDevice();
	engine->play2D("media/DaniHello.wav");
	engine->play2D("media/DistantThunder.wav");
	std::this_thread::sleep_for(std::chrono::milliseconds(2000));
	engine->play2D("media/DaniLaugh.wav");
	std::this_thread::sleep_for(std::chrono::milliseconds(2000));
	ISound* music = engine->play2D("media/Pink Floyd - Set The Controls For The Heart Of The Suni.wav", true, false, true, ESM_AUTO_DETECT, true);
	for (float volume = 0.0f; volume < 1.0f; volume += 0.01) {
		music->setVolume(volume);
		std::this_thread::sleep_for(std::chrono::milliseconds(100));
	}
	engine->play3D("media/airplane-takeoff_daniel_simion.wav",vec3df(0.0,0.0,0.0),true,false,true);
	ISoundEffectControl* fx = music->getSoundEffectControl();
	isRunning = true;
	printf("press 'q' to quit.\n");
	while(isRunning) {	
		c = getchar();
		switch (c) {
		case 'q':
			isRunning = false;
			{
				for (float volume = 1.0f; volume > 0.0f; volume -= 0.01) {
					music->setVolume(volume);
					std::this_thread::sleep_for(std::chrono::milliseconds(30));
				}
				music->stop();
				ISound* finalBoom = engine->play2D("media/Explosion_Ultra_Bass-Mark_DiAngelo.wav");
				while (engine->isCurrentlyPlaying("media/Explosion_Ultra_Bass-Mark_DiAngelo.wav")) {
					std::this_thread::sleep_for(std::chrono::milliseconds(50));
				}
				ISound* giggle = engine->play2D("media/DaniLaugh.wav");
				while (engine->isCurrentlyPlaying("media/DaniLaugh.wav")) {
					std::this_thread::sleep_for(std::chrono::milliseconds(50));
				}

			}

			break;

		case 'b':
			engine->play2D("media/bell.wav");
			break;

		case 'l':
			engine->play2D("media/DaniLaugh.wav");
			break;

		case 's':
			engine->play2D("media/TornadoSiren.wav");
			break;

		case 'r':
			if (fx->isWavesReverbSoundEffectEnabled()) {
				for (float volume = 0.3f; volume < 1.0f; volume += 0.01) {
					music->setVolume(volume);
					std::this_thread::sleep_for(std::chrono::milliseconds(30));
				}
				fx->enableWavesReverbSoundEffect();
				music->setVolume(0.6f);
				fx->disableWavesReverbSoundEffect();
				music->setVolume(1.0f);
			}
			else {
				for (float volume = 1.0f; volume > 0.3f; volume -= 0.01) {
					music->setVolume(volume);
					std::this_thread::sleep_for(std::chrono::milliseconds(30));
				}
				fx->enableWavesReverbSoundEffect();
				music->setVolume(0.3f);
			}
			break;

		case 'd':
			if (fx->isDistortionSoundEffectEnabled())
				fx->disableDistortionSoundEffect();
			else
				fx->enableDistortionSoundEffect();
			break;


		case 'e':
			fx->enableEchoSoundEffect();
			engine->play2D("media/explosion.wav");
			fx->disableEchoSoundEffect();
			break;

		case 'c':
			if (fx->isChorusSoundEffectEnabled())
				fx->disableChorusSoundEffect();
			else
				fx->enableChorusSoundEffect();
			break;
		}
	}
	if(engine) engine->drop(); // delete engine

	return 0;
}