#undef UNICODE

#define WIN32_LEAN_AND_MEAN
#ifdef _WIN32
#include <windows.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <stdlib.h>
#include <stdio.h>
#pragma comment(lib, "Ws2_32.lib")
#endif 

int  main(int argc, char* argv[]) {

    constexpr size_t BUFLEN = 1024;
    const char* PORT = "10080";

    WSADATA wsaData{};
    int status;
    int sendStatus;


    SOCKET ListenSocket = INVALID_SOCKET; /// equates to zero
    SOCKET ClientSocket = INVALID_SOCKET;

    addrinfo* result = nullptr;
    addrinfo hints{};

   
    char recvbuf[BUFLEN];
    int recvbuflen = BUFLEN;

    /// Starting Winsock
    /// The first arg is crazy Microsoft nonsence. 2 2 is the version number converted to a WORD
    status = WSAStartup(MAKEWORD(2, 2), &wsaData);
    if (status != 0) {
        printf("WSAStartup failed with error: %d\n", status);
        return 1; /// In any OS other than MS the return value if main 
    }

    hints.ai_family = AF_INET; /// This means use IPv4
    hints.ai_socktype = SOCK_STREAM;  /// Sequenced two-way communication (TCP)
    hints.ai_protocol = IPPROTO_TCP; /// Use TCP
    hints.ai_flags = AI_PASSIVE; /// "The socket address will be used in a call to the bind function - MS"

    /// Resolve the server address and port
    /// The port is a const char* - why MS?
    /// Notice that result is just a pointer, behind the scenes MS will allocate memory - bad form - where is it freed?
    status = getaddrinfo(nullptr, PORT, &hints, &result);
    if (status != 0) {
        printf("getaddrinfo failed with error: %d\n", status);
        WSACleanup();
        return 1;
    }
    else {
       /// printf();
    }

    /// Create a listening socket for the server. It waits for incomming connections.
    printf("Waiting on a connection\n");
    ListenSocket = socket(result->ai_family, result->ai_socktype, result->ai_protocol);
    if (ListenSocket == INVALID_SOCKET) {
        printf("socket failed with error: %ld\n", WSAGetLastError());
        freeaddrinfo(result);
        WSACleanup();
        return 1;
    }

    // Setup the TCP listening socket and bind it to the OS
    status = bind(ListenSocket, result->ai_addr, static_cast<int>(result->ai_addrlen));
    if (status == SOCKET_ERROR) {
        printf("bind failed with error: %d\n", WSAGetLastError());
        freeaddrinfo(result);
        closesocket(ListenSocket);
        WSACleanup();
        return 1;
    }

    /// This is no longer needed 
    freeaddrinfo(result); /// Don't love this, see "getaddrinfo"
    
    status = listen(ListenSocket, SOMAXCONN); ///SOMAXCONN, I hate MS.
    ///"The maximum length of the queue of pending connections
    ///"SOMAXCONN_HINT is only supported by the Microsoft TCP/IP service provider. 
    /// There is no standard provision to obtain the actual backlog value."
    if (status == SOCKET_ERROR) {
        printf("listen failed with error: %d\n", WSAGetLastError());
        closesocket(ListenSocket);
        WSACleanup();
        return 1;
    }

    /// Accept a client socket from the server socket
    ClientSocket = accept(ListenSocket, nullptr, nullptr);
    if (ClientSocket == INVALID_SOCKET) {
        printf("accept failed with error: %d\n", WSAGetLastError());
        closesocket(ListenSocket);
        WSACleanup();
        return 1;
    }
    else {
        printf("Connected\n");
    }

    /// No longer need server socket
    closesocket(ListenSocket);

    /// Receive data until the client shuts down the connection
    do { /// Personally, I love do while loops - do now, ask permission later 
        printf("Waiting on data\n");
        status = recv(ClientSocket, recvbuf, recvbuflen, 0);
        if (status > 0) {
            printf("Bytes received: %d\n", status);
            printf("Data:\n %s\n", recvbuf);

            /// For now echo the buffer back to the sender
            sendStatus = send(ClientSocket, recvbuf, status, 0);
            if (sendStatus == SOCKET_ERROR) {
                printf("send failed with error: %d\n", WSAGetLastError());
                closesocket(ClientSocket);
                WSACleanup();
                return 1;
            }
            printf("Bytes sent: %d\n", sendStatus);
        }
        else if (status == 0)
            printf("Connection closing...\n");
        else {
            printf("recv failed with error: %d\n", WSAGetLastError());
            closesocket(ClientSocket);
            WSACleanup();
            return 1;
        }

    } while (status > 0);

    /// shutdown the connection
    status = shutdown(ClientSocket, SD_SEND);
    if (status == SOCKET_ERROR) {
        printf("shutdown failed with error: %d\n", WSAGetLastError());
        closesocket(ClientSocket);
        WSACleanup();
        return 1;
    }

    /// Close the socket
    closesocket(ClientSocket);
    WSACleanup();

    return 0;
}