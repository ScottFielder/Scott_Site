#include <iostream>
#include <chrono>
#include <thread>
#include "XBoxController.h"

XBoxController* player0;
int main(int argc, char* argv[]) {
    player0 = new XBoxController(0);
    while (player0->IsConnected()) {
        std::this_thread::sleep_for(std::chrono::milliseconds(50));

        XINPUT_STATE xinput_state = player0->GetState();

        if (xinput_state.Gamepad.wButtons > 0) {
            switch (xinput_state.Gamepad.wButtons) {
            case XINPUT_GAMEPAD_A:
                std::cout << "XINPUT_GAMEPAD_A:\n";
                player0->Vibrate(0xFFFF, 0x0);
                break;

            case XINPUT_GAMEPAD_B:
                std::cout << "XINPUT_GAMEPAD_B\n";
                player0->Vibrate(0x0, 0x0);
                break;

            case XINPUT_GAMEPAD_X:
                std::cout << "XINPUT_GAMEPAD_X\n";
                player0->Vibrate(0x0, 0xFFFF);
                break;

            case XINPUT_GAMEPAD_Y:
                std::cout << "XINPUT_GAMEPAD_Y\n";
                player0->Vibrate(0xFFFF, 0xFFFF);
                break;

            default:
                static int count = 0;
                printf("%x %d\n", xinput_state.Gamepad.wButtons, count);
                ++count;
                break;
            }

        }
        if (xinput_state.Gamepad.bLeftTrigger > 0) {
            /// The trigger returns a byte
            uint8_t leftTrigger = xinput_state.Gamepad.bLeftTrigger;
            printf(" left trigger %X\n", leftTrigger);
        }

        if (xinput_state.Gamepad.bRightTrigger > 0) {
            /// The trigger returns a 8 bit byte range 0 to 255
            uint8_t rightTrigger = xinput_state.Gamepad.bRightTrigger;
            printf(" right trigger %X\n", rightTrigger);
        }

        if (xinput_state.Gamepad.sThumbLX > 0 || xinput_state.Gamepad.sThumbLY > 0) {
            /// The thumb sticks return a signed two byte short 'short' range -32768 to 32767
            int16_t xAxis = xinput_state.Gamepad.sThumbLX;
            int16_t yAxis = xinput_state.Gamepad.sThumbLY;
            printf("LeftThumb event x:%d y:%d\n", xAxis, yAxis);
        }

        if (xinput_state.Gamepad.sThumbRX > 0 || xinput_state.Gamepad.sThumbRY > 0) {
            /// The thumb sticks return a signed two byte short 'short' range -32768 to 32767
            int16_t xAxis = xinput_state.Gamepad.sThumbRX;
            int16_t yAxis = xinput_state.Gamepad.sThumbRY;
            printf("RightThumb event x:%d y:%d\n", xAxis, yAxis);
        }
        
        
    }

    delete player0;
    return 0;

}