#include <fmod.hpp>
#include <fmod_errors.h>
#include <iostream>
#include <vector>
using namespace FMOD;

/// Prototypes
bool LoadAudio(const char* filePath);
bool OnCreate();
void OnDestroy();
void Play(int trackIndex, float volume);


/// Globals
System* soundSystem;
std::vector<Sound*> sounds; /// Store all the audio tracks in advance

int main() {
    if (OnCreate() == false) {
        return 1;
    }

    bool isRunning = true;
    Play(1, 1.0f);
    Play(0, 1.0f);
    Play(2, 1.0f);

    while (isRunning) {
        char command;
        std::cin >> command;

        if (command == 'q') {
            isRunning = false;
            OnDestroy();
        }
        
        soundSystem->update();
    } 
    
    
}

bool LoadAudio(const char* filePath) {
    Sound* sound{};
    FMOD_RESULT result = soundSystem->createStream(filePath, FMOD_DEFAULT, nullptr, &sound);
    if (result != FMOD_OK) {
        std::cerr << "Failed to load sound: " << FMOD_ErrorString(result) << std::endl;
        return false;
    }
    sounds.push_back(sound);
    return true;
}



bool OnCreate() {
    FMOD_RESULT result = System_Create(&soundSystem);
    if (result != FMOD_OK) {
        std::cerr << "FMOD system creation failed: " << FMOD_ErrorString(result) << std::endl;
        return false;
    }

    result = soundSystem->init(32, FMOD_INIT_NORMAL, nullptr);  // Initialize FMOD with 32 channels
    if (result != FMOD_OK) {
        std::cerr << "FMOD system initialization failed: " << FMOD_ErrorString(result) << std::endl;
        return false;
    }

    if (LoadAudio("Limbo.wav") == false){
        return false;
    } 

    if (LoadAudio("Bells.wav") == false){
        return false;
    }

    if (LoadAudio("DistantThunder.wav") == false){
        return false;
    }

    return true;
}


void Play(int trackIndex, float volume) {
    if (trackIndex >= 0 && trackIndex < sounds.size()) {
        Channel* channel{};
        channel->setVolume(volume);
        FMOD_RESULT result = soundSystem->playSound(sounds[trackIndex], nullptr, false, &channel);
        if (result != FMOD_OK) {
            std::cerr << FMOD_ErrorString(result) << std::endl;
        }
        else {
            std::cout << "Audio: " << trackIndex << std::endl;
        }
    }
    else {
        std::cerr << "No such audio track\n";
    }
}

void OnDestroy(){
    for (auto& sound : sounds) {
        sound->release();
    }
    soundSystem->close();
    soundSystem->release();
}

