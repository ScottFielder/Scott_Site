#include <iostream>
#define _CRTDBG_MAP_ALLOC  
#include <stdlib.h>  
#include <crtdbg.h>

#include "Actor.h"
#include "MeshComponent.h"
#include "MaterialComponent.h"
#include "TransformComponent.h"

int main() {
	Actor* mario = new Actor(nullptr);
	mario->AddComponent<MeshComponent>(nullptr);
	mario->AddComponent<MaterialComponent>(nullptr);
	mario->AddComponent<TransformComponent>(nullptr);
	mario->ListComponents();
	TransformComponent* tm = mario->GetComponent<TransformComponent>();
	printf("Transfrom address %p\n",tm); 
	mario->RemoveComponent<TransformComponent>();
	tm = mario->GetComponent<TransformComponent>();
	printf("Transfrom address %p\n",tm); 
	mario->ListComponents();
	

	mario->RemoveAllComponents();
	delete mario;
}