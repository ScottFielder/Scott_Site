#include "MeshComponent.h"

MeshComponent::MeshComponent(Component* parent_):Component(parent_) {}

MeshComponent::~MeshComponent() {}

bool MeshComponent::OnCreate() {
	return true;
}

void MeshComponent::OnDestroy() {}

void MeshComponent::Update(const float deltaTime) {}

void MeshComponent::Render() const {}
