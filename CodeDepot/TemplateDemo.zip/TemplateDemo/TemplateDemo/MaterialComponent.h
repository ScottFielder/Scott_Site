#pragma once
#include "Component.h"
class MaterialComponent : public Component {
public:
	MaterialComponent(Component* parent_);
	~MaterialComponent();
	virtual bool OnCreate() override;
	virtual void OnDestroy() override;
	virtual void Update(const float deltaTime) override;
	virtual void Render() const;

};

