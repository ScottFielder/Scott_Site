#pragma once
#include "Component.h"
class TransformComponent : public Component {
public:
	TransformComponent(Component* parent_);
	~TransformComponent();
	virtual bool OnCreate() override;
	virtual void OnDestroy() override;
	virtual void Update(const float deltaTime) override;
	virtual void Render() const;
};
