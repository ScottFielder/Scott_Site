#include "TransformComponent.h"
TransformComponent::TransformComponent(Component* parent_):Component(parent_) {}

TransformComponent::~TransformComponent() {}

bool TransformComponent::OnCreate() {
	return true;
}

void TransformComponent::OnDestroy() {}

void TransformComponent::Update(const float deltaTime) {}

void TransformComponent::Render() const {}