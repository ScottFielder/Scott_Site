#ifndef QUATERTNION_H
#define QUATERTNION_H
#include <iostream>
#include "ConstantsConversions.h"
#include "VMath.h"
#include "Matrix.h"

/// A quaternion can be written as a scalar plus a 3-vector (Vec3 ijk) component or


namespace  MATH {
union Quaternion {
public:
	struct {
		float i;
		float j;
		float k;
		float w;
	};

	struct {
		Vec3 ijk; /// These are the ijk components of the Quaternion 
		float w;
	};


	struct {
		float e32;  // i is -e23 
		float e13;  // j is -e31
		float e21;  // k is -e12
		float real;
	};

	

	/// Just a little utility to populate a quaternion
	inline void set(float w_, float x_, float y_, float z_) {
		w = w_; ijk.x = x_; ijk.y = y_; ijk.z = z_;
	}

	/// Another little utility to populate a quaternion
	inline void set(float w_, Vec3 ijk_) {
		w = w_; ijk.x = ijk_.x; ijk.y = ijk_.y; ijk.z = ijk_.z;
	}

	/// This is the unit quaterion by definition 
	inline Quaternion() {
		set(1.0f, 0.0f, 0.0f, 0.0f);
	}

	inline Quaternion(float w_, const Vec3& ijk_) {
		set(w_, ijk_.x, ijk_.y, ijk_.z);
	}

	/// A copy constructor
	inline Quaternion(const Quaternion& q) {
		set(q.w, q.ijk.x, q.ijk.y, q.ijk.z);
	}

	/// An assignment operator   
	inline Quaternion& operator = (const Quaternion& q) {
		set(q.w, q.ijk.x, q.ijk.y, q.ijk.z);
		return *this;
	}

	/// Take the negative of a Quaternion
	inline const Quaternion operator - () const {
		return Quaternion(-w, Vec3(-ijk.x, -ijk.y, -ijk.z));
	}

	/// Multiply a two quaternions - using the right-hand rule 
	/// 2022-02-12 Scott edit. Worried that Umer uncovered a bug in my code,
	/// I derived the multiply over again (this time less sexy) and it seems to work 
	/// correctly.
	inline const Quaternion operator * (const Quaternion& q) const {
		Quaternion result;
		result.w = (w * q.w) - (ijk.x * q.ijk.x) - (ijk.y * q.ijk.y) - (ijk.z * q.ijk.z);
		result.ijk.x = (w * q.ijk.x) + (ijk.x * q.w) - (ijk.z * q.ijk.y) + (ijk.y * q.ijk.z);
		result.ijk.y = (w * q.ijk.y) + (ijk.y * q.w) - (ijk.x * q.ijk.z) + (ijk.z * q.ijk.x);
		result.ijk.z = (w * q.ijk.z) + (ijk.z * q.w) - (ijk.y * q.ijk.x) + (ijk.x * q.ijk.y);
		return result;		
	}

	inline const Quaternion& operator *= (const Quaternion& q) {
		*this = q * *this;
		return *this;
	}

	inline const Quaternion operator + (const Quaternion q) const {
		return Quaternion(w + q.w, Vec3(ijk.x + q.ijk.x, ijk.y + q.ijk.y, ijk.z + q.ijk.z));
	}

	inline const Quaternion operator - (const Quaternion q) const {
		return Quaternion(w - q.w, Vec3(ijk.x - q.ijk.x, ijk.y - q.ijk.y, ijk.z - q.ijk.z));
	}

	inline const Quaternion operator * (const float scalar) const {
		return Quaternion(w * scalar, Vec3(ijk.x * scalar, ijk.y * scalar, ijk.z * scalar));
	}

	inline const Quaternion operator / (const float scalar) const {
		return Quaternion(w / scalar, Vec3(ijk.x / scalar, ijk.y / scalar, ijk.z / scalar));
	}

	/// Now we can use the Quaternion like an array but we'll need two overloads
	inline const float operator [] (int index) const {  /// This one is for reading the Quaternion as if where an array
		return *((float*)this + index);
	}

	inline float& operator [] (int index) {	/// This one is for writing to the Quaternion as if where an array.  
		return *((float*)this + index);
	}

	inline void print(const char* comment = nullptr) const {
		if (comment) printf("%s\n", comment);
		printf("%1.4f %1.4f %1.4f %1.4f\n", ijk.x, ijk.y, ijk.z, w);
	}


	/////////////////////////////////////////////////////////////////////////
	/// This is just for teaching purposes - Caution, I'm getting out of control
	/////////////////////////////////////////////////////////////////////////
	/// Multiply a quaternion by a Vec3 (Quaternion * Vec3) 
	inline const Vec3 operator * (const Vec3& v_) const {
		/// Promote the Vec3 to a Quaternion and set w to be 0.0
		Quaternion p(0.0, v_);
		/// Now just call the Quaternion * Quaternion operator
		Quaternion result = *this * p;
		return result.ijk;
	}
	/// Multiply a Vec3 by a Quaternion (Vec3 * Quaternion) 
	friend Vec3 operator * (const Vec3 v, const Quaternion& q) {
		Quaternion qv(0.0f, v);
		Quaternion result = qv * q;
		return result.ijk;
	}

	/// Seriously, the tilde ~ is the complement operator not the 
	///  conjugate - but it was for fun. 
	inline Quaternion operator~() { return Quaternion(w, -ijk); }
	/////////////////////////////////////////////////////////////////////////


	};
}
#endif
