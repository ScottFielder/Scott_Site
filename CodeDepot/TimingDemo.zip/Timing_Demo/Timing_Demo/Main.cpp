#include "Timing.h"
#include <vector>

int main() {
	
	
	{   /// This keeps the code 8-12 within a single scope
		/// When the program reaches } (line 16) the code goes
		/// out of scope and the Timing object will call the destructor
		/// The Timer will then print the deltaTime from 11 -> 16
		Timing timing("main1");
		std::vector<int> list;
		for (int i = 0; i < 100000; ++i) {
			list.push_back(i);
		}
	}

	{
		Timing timing("main2");
		std::vector<int> list;
		for (int i = 0; i < 10000000; ++i) {
			list.push_back(i);
		}
	}

}
