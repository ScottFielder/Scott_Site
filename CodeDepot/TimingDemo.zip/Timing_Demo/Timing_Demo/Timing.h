#ifndef TIMING_H
#define TIMING_H
#include <iostream>
#include <chrono>


class Timing {
private:
	const char* blockName; /// Give the timing block a name 
	std::chrono::time_point<std::chrono::steady_clock> startTime;
	std::chrono::time_point<std::chrono::steady_clock> endTime;

public:
	/// Grab the current time upon construction of Timer  
	Timing(const char* name):blockName(name) {
		startTime = std::chrono::high_resolution_clock().now();
	}

	~Timing() {
		/// When timer dies, grab the time - subtract from startTime = deltaTime
		endTime =  std::chrono::high_resolution_clock().now();
		long long start = std::chrono::time_point_cast<std::chrono::microseconds>(startTime).time_since_epoch().count();
		long long end = std::chrono::time_point_cast<std::chrono::microseconds>(endTime).time_since_epoch().count();
		std::cout << blockName << ": " << end - start << " microseconds\n";	
	}
};
#endif
