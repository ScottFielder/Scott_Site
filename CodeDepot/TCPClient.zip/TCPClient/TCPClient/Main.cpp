#include <SDL.h>
#include <SDL_net.h>
#include <thread>
#include <chrono>

#include <cstdio>
#include <cstring>
#include <iostream>


#define BUFFER_SIZE 1024

NET_Address *address; 
NET_StreamSocket* socket;

int main(int argc, char *argv[]) {
    
    char data[BUFFER_SIZE];

    if (NET_Init() == false) {
        std::cerr << SDL_GetError() << std::endl;
        exit(EXIT_FAILURE);
    }
  
   
    /// Contact the DNS server to resolve the name into an address
    address = NET_ResolveHostname("127.0.0.1");
    NET_WaitUntilResolved(address, -1);
    if(address == nullptr) {
        std::cerr << SDL_GetError() << std::endl;
        NET_Quit();
        exit(EXIT_FAILURE);
    }
    std::cout << NET_GetAddressString(address);

    NET_WaitUntilResolved(address,2000);
    /// Connect to the server
    socket = NET_CreateClient(address, 0x1A2C,0);
    NET_WaitUntilConnected(socket, -1);
    if(socket == nullptr) {  /// Maybe no one is listening
        std::cerr << SDL_GetError() << std::endl;
        exit(EXIT_FAILURE);
    }
    /// I have a connection 

    /// Let's work this next part out together, Assignment 1

    sprintf_s(data, "%s\n", "Hello Scott");

    NET_WriteToStreamSocket(socket, data, BUFFER_SIZE);
    /// Let's work this next part out together, Assignment 1


    NET_DestroyStreamSocket(socket);
    NET_Quit();
    SDL_Quit();
}