#include <SDL.h>
#include <SDL_net.h>
#include <cstdio>
#include <cstring>
#include <iostream>

#define BUFFER_SIZE 1024
int main(int argc, char *argv[]) {
    bool done = false;
    TCPsocket server, client;
    TCPsocket tcpSocket;
    IPaddress ip;
    char message[BUFFER_SIZE];

    if (SDLNet_Init()  < 0) {
        printf("SDLNet_Init: %s\n", SDLNet_GetError());
        exit(EXIT_FAILURE);
    }
    printf("Starting the client side\n");
  
   

    if (SDLNet_ResolveHost(&ip, "127.0.0.1", 60400) == -1) {
        printf("SDLNet_ResolveHost: %s\n", SDLNet_GetError());
        exit(EXIT_FAILURE);
    }

    tcpSocket = SDLNet_TCP_Open(&ip);
    if (tcpSocket == nullptr) {
        printf("SDLNet_TCP_Open: %s\n", SDLNet_GetError());
        exit(EXIT_FAILURE);
    }

    while (1) {
        printf("message: ");
        
        fgets(message, BUFFER_SIZE, stdin);
        int len = strlen(message);

       /// Kill the new line char replace it with a null char
        message[len - 1] = '\0';

        if (len) {
        int result;

        /// Try this with std::cout!
        /// The asterisk means that the length of the %s string will be 
        /// specified by the first argument (len). 
        printf("Sending  %.*s\n", len, message);

        result = SDLNet_TCP_Send(tcpSocket, message, len); 
        if (result < len)
            printf("SDLNet_TCP_Send: %s\n", SDLNet_GetError());
        }

        if (tolower(message[0]) == 'q') {
            break;
        }
    }

SDLNet_TCP_Close(tcpSocket);
SDLNet_Quit();
SDL_Quit();
}