#include <iostream>
#include <string.h>
#include <SDL3/SDL.h>
#include <SDL3/SDL_net.h>
#include <stdlib.h>

void Server(); /// Prototyping


int main(int argc, char*argv[]){
	Server();
	return 1;
}

struct DATE {
	int day;
	int month;
	int year;
};

union PKG {
	DATE date;
	char buffer[sizeof(DATE)];
};


void Server(){
	NET_DatagramSocket *sd;       /// Socket descriptor 
	NET_Datagram *p;       /// Pointer to packet memory */
	int quit;
 
	/// Initialize SDL_net
	if (NET_Init() < 0) {
		std::cerr << SDL_GetError() << std::endl;
		exit(EXIT_FAILURE);
	}
 
	/// Open a socket and bind the port to the OS
	if (!(sd = NET_CreateDatagramSocket(NULL,0x1A2B))) {
		std::cerr << SDL_GetError() << std::endl;
		exit(EXIT_FAILURE);
	}
 
	 //Make space for the packet
	p = new NET_Datagram{};
	p->port = 0x1A2B;
	p->buf = (Uint8* )malloc(512);
	
 
	/// Main loop

	std::cout << "Listening: " << std::endl;
	quit = 0;
	while (!quit) {
		/// Wait a packet. UDP_Recv returns != 0 if a packet is coming
		if (NET_ReceiveDatagram(sd, &p)){
			if (p == NULL) {
				continue;
			}
			PKG pkg;
			strcpy_s(pkg.buffer,sizeof(PKG), (char*)p->buf);

			std::cout << "UDP Packet incoming" << std::endl;
			std::cout << "Data: " <<  p->buf << std::endl;

			std::cout << "Day: " <<  pkg.date.day << std::endl;
			std::cout << "Month: " <<  pkg.date.month << std::endl;
			std::cout << "Year: " <<  pkg.date.year << std::endl;

			std::cout << "Len: " <<  std::dec << p->buflen << std::endl;
			std::cout << "Address: " <<  std::hex << p->addr << ": " << std::hex << p->port << std::endl << std::endl;
			
 
			/// Quit if packet contains "quit"
			if (strcmp((char *)p->buf, "quit") == 0)
				quit = 1;

			
		}		
	}
 
	/// Clean up and exit the program 
	NET_DestroyDatagram(p);
	NET_Quit();
	return;
}