#include <iostream>
#include <string.h>
#include <SDL.h>
#include <SDL_net.h>

void Server(); /// C-style prototyping


int main(int argc, char*argv[]){
	Server();
	return 0;
}



union PKG {
	char buffer[512];
};


void Server(){
	UDPsocket sd;       /// Socket descriptor 
	UDPpacket *p;       /// Pointer to packet memory
	int quit;
 
	/// Initialize SDL_net
	if (SDLNet_Init() < 0) {
		std::cerr << SDLNet_GetError() << std::endl;
		exit(EXIT_FAILURE);
	}
 
	/// Open a socket and bind the port to the OS
	if (!(sd = SDLNet_UDP_Open(0x1A2B))) {
		std::cerr << SDLNet_GetError() << std::endl;
		exit(EXIT_FAILURE);
	}
 
	/// Make space for the packet
	if (!(p = SDLNet_AllocPacket(512)))
	{
		std::cerr << SDLNet_GetError() << std::endl;
		exit(EXIT_FAILURE);
	}
 
	/// Main loop

	std::cout << "Listening: " << std::endl;
	quit = 0;
	while (!quit) {
		/// Wait a packet. UDP_Recv returns != 0 if a packet is coming
		if (SDLNet_UDP_Recv(sd, p)){
			PKG pkg;
			strcpy_s(pkg.buffer,sizeof(PKG), (char*)p->data);

			std::cout << "UDP Packet incoming" << std::endl;
			std::cout << "Data: " <<  p->data << std::endl;

			std::cout << "Len: " <<  std::dec << p->len << std::endl;
			std::cout << "Address: " <<  std::hex << p->address.host << ": " << std::hex << p->address.port << std::endl << std::endl;
			std::cout << "Channel: "  << std::dec << p->channel << std::endl << std::endl;
 
			/// Quit if packet contains "quit"
			if (strcmp((char *)p->data, "quit") == 0)
				quit = 1;
		}		
	}
 
	/// Clean up and exit the program 
	SDLNet_FreePacket(p);
	SDLNet_Quit();
	return;
}