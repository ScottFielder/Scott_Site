#include "Scene1.h"
#include <SDL3/SDL.h>
#include <MMath.h>
#include <iostream>
#include "Entity.h"

Scene1::Scene1(SDL_Window* sdlWindow_)
{
	std::cout << "Loading Scene 1\n";
	window = sdlWindow_;
	xAxis = 15.0f;
	yAxis = 30.0f;


	posY = 0.0f;
}

Scene1::~Scene1()
{
}

bool Scene1::OnCreate()
{
	return true;
}

void Scene1::OnDestroy()
{
}

void Scene1::HandleEvents(const SDL_Event& event)
{
}

void Scene1::Update(const float time)
{
	posY = posY + 0.1f;
	std::cout << "Pos Y is: " << posY << std::endl;;
}

void Scene1::Render() const
{
}
