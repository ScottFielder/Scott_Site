#ifndef SCENE1_H
#define SCENE1_H
#include <SDL3/SDL.h>
#include <Matrix.h>
#include "Scene.h"
#include "Entity.h"
/* In this Scene main task will be to practice basic stuff like variables, methods, if/else and so on with just Console.
	This is going to be the material for the first few weeks. 
*/

using namespace MATH;
class Scene1 : public Scene {
private:
	SDL_Window *window;
	float xAxis; 
	float yAxis;
	
	float posY;
	float posX;
public:
	Scene1(SDL_Window* sdlWindow_);
	~Scene1();

	bool OnCreate() override;
	void OnDestroy() override;
	void HandleEvents(const SDL_Event& event) override;
	void Update(const float time) override;
	void Render() const override;
};

#endif

