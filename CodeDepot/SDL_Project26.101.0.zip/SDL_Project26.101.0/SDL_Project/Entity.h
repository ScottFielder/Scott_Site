#ifndef ENTITY_H
#define ENTITY_H

#include <Vector.h>
#include <SDL3/SDL.h>
using namespace MATH;

class Entity {
private:
	// Keep these private as we should only build them in the setImage method
	SDL_Surface* surface; // Used to get the width and height of the image
	SDL_Texture* texture; // Used to render the image

public:
	float angleDeg;
	Vec3 pos;

	Entity();
	~Entity();
	void SetImage(const char* filename, SDL_Renderer* renderer);

	// Need getters for private member variables
	SDL_Surface* GetSurface() const { return surface; }
	SDL_Texture* GetTexture() const { return texture; }
};

#endif
