#include <iostream>
#include <memory>

/// I will start by making a simple class
class Dog {
public:
    Dog() {
        std::cout << "Hello from the constructor\n";
    }
    ~Dog() {
        std::cout << "Good-bye from the destructor\n";
    }
    void Bark() {
        std::cout << "Arf!\n";
    }
};


int main() {
    Dog* d = new Dog();
    d->Bark();
    delete d; 
    /// So far, no big deal 

    /// Now invoke a unique_ptr. 
    std::unique_ptr<Dog> dog( new Dog() ); /// the address is safe in the smart pointer.
    dog->Bark(); /// It still works like a pointer (with the overloaded -> operator).
    /// Look at the output - but I never called delete, cool.  
}