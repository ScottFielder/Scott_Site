#include <iostream>
#include <memory>
#include <vector>

using namespace std;

class Component {
public:
	Component(Component* parent_): parent(parent_){
		cout << "Hello from Component constructor\n";
	}

	virtual ~Component() {
		cout << "Bye from Component destructor\n";
	}

	virtual void DoSomething() {
		cout << "Some component action\n";
	}

protected:
	Component* parent;
};


class Mesh : public Component {
public:
	Mesh():Component(nullptr) {
		cout << "Hello from Mesh constructor\n";
	}

	virtual ~Mesh() {
		cout << "Bye from Mesh destructor\n";
	}

	virtual void DoSomething() {
		cout << "Some component Mesh action\n";
	}
};


class Material : public Component {
public:
	Material():Component(nullptr) {
		cout << "Hello from Material constructor\n";
	}
	virtual ~Material() {
		cout << "Bye from Material destructor\n";
	}
	virtual void DoSomething() {
		cout << "Some component Material action\n";
	}

};
/// Global are bad!!!!
vector< shared_ptr<Component> > components;

template<typename ComponentTemplate>
shared_ptr<Component> GetComponent() {
	for (shared_ptr<Component> c : components) {
		Component* componentPtr = c.get();
		if (dynamic_cast<ComponentTemplate*>(componentPtr)) {
			return c;
		}
	}
	return shared_ptr<Component>(nullptr);
}

template<typename ComponentTemplate>
void RemoveComponent() {
	for (int i = 0; i < components.size(); i++) {
		Component* componentPtr = components[i].get();
		if (dynamic_cast<ComponentTemplate*>(componentPtr)) {
			components.erase(components.begin() + i);
			break;
		}
	}
}


int main() {

	shared_ptr<Component> material(new Material()); 
	components.push_back(material); 

	components.push_back(shared_ptr<Mesh>(new Mesh())); 

	for (auto c : components) { 
		c->DoSomething();
		cout << c.use_count() << endl;
	}


	auto m = GetComponent<Mesh>();
	m->DoSomething();
	
}
