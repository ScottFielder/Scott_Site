#include <glew.h>
#include <iostream>
#include <SDL.h>
#include "Debug.h"
#include "Scene0.h"
#include "Vector.h"
#include "MMath.h"
#include "Debug.h"
#include "imgui.h"
#include "imgui_impl_opengl3.h"

Scene0::Scene0():backGroundColor(0.0f,0.0f,0.0f,0.0f) {
	Debug::Info("Created Scene0: ", __FILE__, __LINE__);
}

Scene0::~Scene0() {
	Debug::Info("Deleted Scene0: ", __FILE__, __LINE__);

}

bool Scene0::OnCreate() {
	Debug::Info("Loading assets Scene0: ", __FILE__, __LINE__);
	return true;
}

void Scene0::OnDestroy() {
	Debug::Info("Deleting assets Scene0: ", __FILE__, __LINE__);
}
void Scene0::HandleEvents(const SDL_Event &sdlEvent) {
	switch( sdlEvent.type ) {
    case SDL_KEYDOWN:
		break;

	case SDL_MOUSEMOTION:          
		break;

	case SDL_MOUSEBUTTONDOWN:              
		break; 

	case SDL_MOUSEBUTTONUP:            
	break;

	default:
		break;
    }
}

void Scene0::Update(const float deltaTime) {
	HandleTheGUI();
}


/// This is just an example of what I thought of, you go do something better - think!
void Scene0::HandleTheGUI() {
	bool open = true;
	ImGui::Begin("Frame rate",&open,ImGuiWindowFlags_NoTitleBar|ImGuiWindowFlags_NoMove|ImGuiWindowFlags_NoBackground);
	ImGui::Text("%.1f ms/frame (%.1f FPS)", 1000.0f / ImGui::GetIO().Framerate, ImGui::GetIO().Framerate);
	ImGui::End();

	ImGui::Begin("Background color");                        
	ImGui::ColorEdit3("background color", backGroundColor);  
	ImGui::End();
  
}

void Scene0::Render() const {
	
	/// Clear the screen
	glClearColor(backGroundColor.x, backGroundColor.y, backGroundColor.z, backGroundColor.w );
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glUseProgram(0);
}



	
