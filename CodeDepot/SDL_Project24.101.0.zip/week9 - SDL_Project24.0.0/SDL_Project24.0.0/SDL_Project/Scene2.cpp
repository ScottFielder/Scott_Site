#include "Scene2.h"
#include <SDL.h>
#include <SDL_image.h>
#include <MMath.h>
#include <iostream>
#include "Entity.h"

Scene2::Scene2(SDL_Window* sdlWindow_){
	window = sdlWindow_;
	renderer = nullptr;
	planet = nullptr;
	xAxis = 60.0f;
	yAxis = 30.0f;
	IMG_Init(IMG_INIT_PNG);
	clickedOnPlanet = false;
}

Scene2::~Scene2(){
	IMG_Quit();
}

bool Scene2::OnCreate() {
	int w, h;
	SDL_GetWindowSize(window,&w,&h);
	Matrix4 ndc = MMath::viewportNDC(w, h);
	Matrix4 ortho = MMath::orthographic(0.0f, xAxis, 0.0f, yAxis, -1.0f, 1.0f);
	projectionMatrix = ndc * ortho;
	renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
	

	planet = new Entity();
	planet->pos = Vec3(10.0f, 20.0f, 0.0f);
	planet->SetImage("walk_spritesheet.png", renderer);
	planet->mass = 1;
	planet->r = 2;

	star1 = new Entity();
	star1->pos = Vec3(5, 10, 0);
	star1->SetImage("star.png", renderer);
	star1->mass = 100;

	// TODO FOR YOU
	// Set up star2 as well

	return true;
}

void Scene2::OnDestroy() {
	delete planet;
	planet = nullptr;

	delete star1;
	star1 = nullptr;
}

void Scene2::HandleEvents(const SDL_Event& event)
{
	switch (event.type) {
	case SDL_KEYDOWN:
		// Change angle
		if (event.key.keysym.scancode == SDL_SCANCODE_O) {
			planet->angleDeg -= 10.0f;
		}
		if (event.key.keysym.scancode == SDL_SCANCODE_P) {
			planet->angleDeg += 10.0f;
		}
		break;

	case SDL_MOUSEBUTTONDOWN:
		// Get physics coordinate of mouse position
	{
		Vec3 mousePosPixelSpace(event.button.x, event.button.y, 0.0f);
		Matrix4 worldToPixelSpace = projectionMatrix;
		Matrix4 pixelToWorldSpace = MMath::inverse(projectionMatrix);

		Vec3 mousePosWorldSpace = pixelToWorldSpace * mousePosPixelSpace;
		mousePosPixelSpace.print("mouse pos pixel space");
		mousePosWorldSpace.print("mouse pos world space");
		// check if mouse is within the radius of the circle
		Vec3 centreToMouse = mousePosWorldSpace - planet->pos;
		float distance = sqrt(
			centreToMouse.x * centreToMouse.x +
			centreToMouse.y * centreToMouse.y);
		// Check if distance is less than the radius
		if (distance <= planet->r) {
			clickedOnPlanet = true;
		}

	}
		break;

	default:
		break;
	}
}


void Scene2::Update(const float deltaTime) {
	/// Physics goes here
	// Following my instructions in the assignment doc
	// STEP 1
	// Find vector from planet to star 1
	// Vec3 PS1 = ....

	// STEP 2
	// Find distance from planet to star 1
	// Use pythag theory
	// float r1 = ...

	// STEP 3
	// Find the magnitude of the force of gravity
	// Code up Newtons Law of Gravitation
	// float fg1_magnitude = ...

	// STEP 4
	// Find the direction of gravity from planet to star 1
	// Normalize the vector from planet to star 1
	// Vec3 fg1_direction = ....

	// STEP 5
	// Combine magnitude with direction
	// Vec3 fg1 = fg1_magnitude * fg1_direction;

	// STEP 6
	// Do this all over again (steps 1 - 5) for star 2

	// STEP 7
	// Add up the forces
	Vec3 totalForce;
	// totalForce = fg1 + fg2;
	   	  
	planet->ApplyForce(totalForce);
	planet->Update(deltaTime);


	if (clickedOnPlanet) {
		// fake physics
		planet->pos.x += 2*deltaTime;
	}





	// Make a circle around planet
	for (int i = 0; i < planet->points.size(); i++) {
		float angleDeg = i; // Scott will hate this, I need to cast into a float
		float angleRad = angleDeg * 2 * M_PI / 360.0f;
		// Following Umer's scribbles on the board
		// Patryck says, also add flappy's pos
		planet->points[i].x = planet->r * cos(angleRad) + planet->pos.x;
		planet->points[i].y = planet->r * sin(angleRad) + planet->pos.y;
	}

}

void Scene2::Render() const {
	SDL_SetRenderDrawColor(renderer, 0, 0, 0, 0);
	SDL_RenderClear(renderer);
	{
		Vec3 screenCoords = projectionMatrix * planet->pos;
		SDL_Rect square;
		square.x = static_cast<int>(screenCoords.x);
		square.y = static_cast<int>(screenCoords.y);
		float scale = 1.0f;
		square.w = planet->GetSurface()->w * scale / 8;
		square.h = planet->GetSurface()->h * scale;

		SDL_Rect sprite;
		sprite.w = planet->GetSurface()->w / 8;
		sprite.h = planet->GetSurface()->h;
		sprite.y = 0;
		
	
		// Play nice with Scott, and change a local static variable
		// as Render is const
		static int counter = 0;
		// Slow down our animation
		static int frameCounter = 0;
		frameCounter++;
		// How many frames should we keep each sprite on the screen for?
		const int numFrames = 8;
		frameCounter = frameCounter % numFrames;
		// Change the sprite we are looking at 
		// when frameCounter is back to zero
		if (frameCounter == 0) {
			counter++;
		}
		if (counter > 7) {
			counter = 0;
		}
		///sprite.x = planet->GetSurface()->w / 8; // Change this to 0, w/8, 2w/8, 3w/8, 4w/8, 5w/8, 6w/8, 7w/8, then back to zero
		sprite.x = counter * planet->GetSurface()->w / 8;

		SDL_RenderCopyEx(renderer, planet->GetTexture(), &sprite, &square, planet->angleDeg, nullptr, SDL_FLIP_NONE);
	}

	{
		Vec3 screenCoords = projectionMatrix * star1->pos;
		SDL_Rect square;
		square.x = static_cast<int>(screenCoords.x);
		square.y = static_cast<int>(screenCoords.y);
		float scale = 0.5f;
		square.w = star1->GetSurface()->w * scale;
		square.h = star1->GetSurface()->h * scale;
		SDL_RenderCopyEx(renderer, star1->GetTexture(), nullptr, &square, star1->angleDeg, nullptr, SDL_FLIP_NONE);
	}




	// Draw circle of points
	SDL_SetRenderDrawColor(renderer, 255, 255, 255, 0);
	for (int i = 0; i < planet->points.size(); i++){
		Vec3 screenCoords = projectionMatrix * planet->points[i];
		SDL_RenderDrawPoint(
			renderer, 
			static_cast<int>(screenCoords.x), 
			static_cast<int>(screenCoords.y));
	}
	
	SDL_RenderPresent(renderer);
}