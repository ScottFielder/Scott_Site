﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

public class UdpClientSender {
    public static async Task SendMessageAsync(string hostname, int port, string message) {
        using (UdpClient udpClient = new UdpClient()){

            try {
                byte[] sendBytes = Encoding.ASCII.GetBytes(message);
                await udpClient.SendAsync(sendBytes, sendBytes.Length, hostname, port);
                Console.WriteLine($"Sent message to {hostname}:{port}: {message}");


                UdpReceiveResult receiveResult = await udpClient.ReceiveAsync();
                IPEndPoint remoteEndPoint = receiveResult.RemoteEndPoint;
                string reply = Encoding.ASCII.GetString(receiveResult.Buffer);
                Console.WriteLine($"Received reply from {remoteEndPoint.Address}:{remoteEndPoint.Port}: {reply}");
            }
            catch (SocketException se) {
                Console.WriteLine($"SocketException message: {se.Message}");
            }
            catch (Exception ex) {
                Console.WriteLine($"Exception message: {ex.Message}");

            }
        }
    }

    public static async Task Main(string[] args) {
        
        string serverName = "127.0.0.1"; 
        int port = 0x1A2B;
        string message = "Hi Game Programmers";

        await SendMessageAsync(serverName, port, message);

        Console.WriteLine("Press any key to exit.");
        Console.ReadKey();
    }
}

