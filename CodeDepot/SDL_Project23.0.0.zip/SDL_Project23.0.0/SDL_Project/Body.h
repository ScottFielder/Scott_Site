#include <Vector.h>
#include <SDL_image.h>
using namespace MATH;

class Body {
private:
	Vec3 pos;
	Vec3 vel;
	Vec3 accel;
	SDL_Surface* image;

public:
	Body();
	~Body();
	void Update(float deltaTime);
	Vec3 getPos() { return pos; }
	Vec3 getVel() { return vel; }
	void setVel(const Vec3 vel_) { vel = vel_; }
	void setImage(SDL_Surface* image_) { image = image_; }
	SDL_Surface* getImage() { return image; }
};

