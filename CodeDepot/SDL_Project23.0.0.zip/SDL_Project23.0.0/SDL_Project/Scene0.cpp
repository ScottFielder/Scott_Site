#include "Scene0.h"
#include <SDL.h>
#include <SDL_image.h>
#include <MMath.h>
#include <iostream>

Scene0::Scene0(SDL_Window* sdlWindow_){
	window = sdlWindow_;
	renderer = nullptr;
	ball = nullptr;
}

Scene0::~Scene0(){
	
}

bool Scene0::OnCreate() {
	int w, h;
	float xAxis = 30.0f;
	float yAxis = 15.0f;
	SDL_GetWindowSize(window,&w,&h);
	 
	Matrix4 ndc = MMath::viewportNDC(w, h);
	Matrix4 ortho = MMath::orthographic(0.0f, xAxis, 0.0f, yAxis, 0.0f, 1.0f);
	projectionMatrix = ndc * ortho;
	renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
	IMG_Init(IMG_INIT_PNG);

	ball = new Body();

	SDL_Surface* ballImage = IMG_Load("ball.png");
	if(ballImage == nullptr){
		std::cerr << "Can't open the image" << std::endl;
		return false;
	}
	ball->setImage(ballImage);
	return true;
}

void Scene0::OnDestroy() {
	delete ball;
}

void Scene0::Update(const float deltaTime) {
	ball->Update(deltaTime);	
}

void Scene0::Render() {
	SDL_Surface *screenSurface = SDL_GetWindowSurface(window);
	SDL_FillRect(screenSurface, nullptr, SDL_MapRGB(screenSurface->format, 0, 0, 0));

	Vec3 screenCoords = projectionMatrix * ball->getPos();
	SDL_Rect square;
	square.x = static_cast<int>(screenCoords.x);
	square.y = static_cast<int>(screenCoords.y);
	square.w = ball->getImage()->w;
	square.h = ball->getImage()->h;
	SDL_BlitSurface(ball->getImage(),nullptr,screenSurface,&square);
	SDL_UpdateWindowSurface(window);
}