#include "Body.h"

Body::Body() {
	image = nullptr;
}


Body::~Body(){

}


void Body::Update(float deltaTime){
	
}
