#include <SDL.h>
#include <SDL3_net/SDL_net.h>

#include <thread>
#include <chrono>

#include <cstdio>
#include <cstring>
#include <iostream>

#define BUFFER_SIZE 1024

NET_Server* server;
NET_StreamSocket* socket; 

int main(int argc, char *argv[]) {
    bool done = false;
    char data[BUFFER_SIZE];
    
    if (NET_Init() == false) {
        std::cerr << SDL_GetError() << std::endl;
        exit(EXIT_FAILURE);
    }
    
    /// Create a "listener" waiting for and in coming connection on port 0x1A2C
    if (server = NET_CreateServer(nullptr, 0x1A2C,0)) {
        std::cerr << SDL_GetError() << std::endl;
        exit(EXIT_FAILURE);
    }

    /// Wait for a connection
    while( NET_AcceptClient(server, &socket) == false){
        std::this_thread::sleep_for(std::chrono::milliseconds(50));
    }

    /// I have a connection 
    
     /// Let's work this next part out together, Assignment 1
    


    NET_DestroyStreamSocket(socket);
    NET_Quit();
    return 0;
}