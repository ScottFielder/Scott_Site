#include <SDL.h>
#include <SDL_net.h>
#include <cstdio>
#include <cstring>
#include <iostream>
#define BUFFER_SIZE 1024
int main(int argc, char *argv[]) {
    bool done = false;
    TCPsocket server, client;
    IPaddress ip;
    char buffer[BUFFER_SIZE];
    
    if (SDLNet_Init()  < 0) { /// Init the network subsystem
        printf("SDLNet_Init: %s\n", SDLNet_GetError());
        exit(EXIT_FAILURE);
    }
    printf("The server is listening\n");
    
    if (SDLNet_ResolveHost(&ip, NULL, 60400) == -1) {
      printf("SDLNet_ResolveHost: %s\n", SDLNet_GetError());
      exit(EXIT_FAILURE);
    }
    server = SDLNet_TCP_Open(&ip);
    if (server == nullptr) {
      printf("SDLNet_TCP_Open: %s\n", SDLNet_GetError());
      exit(EXIT_FAILURE);
    }
    while (!done) {
      /// Accept a connection from the client 
      client = SDLNet_TCP_Accept(server);
      if (client == nullptr) { /// if no connection loop around and check again 
        SDL_Delay(100); /// in milliseconds
        continue;
      }

      
      IPaddress *remoteip = nullptr;
      remoteip = SDLNet_TCP_GetPeerAddress(client);
      if (remoteip == nullptr) {
        printf("SDLNet_TCP_GetPeerAddress: %s\n", SDLNet_GetError());
        continue;
      }

      /// Get some info about the the client socket
      Uint32 ipaddr = 0;
      ipaddr = SDL_SwapBE32(remoteip->host);
      /// Ha! Bit shifts and masks
      printf("Connected from: %d.%d.%d.%d on port %d\n", ipaddr >> 24,
             (ipaddr >> 16) & 0xff, (ipaddr >> 8) & 0xff, ipaddr & 0xff,
             remoteip->port);

      while (1) {  /// forever
        /// read data from the client  
        /// this function will block execution if there is no data 
        int len = SDLNet_TCP_Recv(client, buffer, BUFFER_SIZE);
        if (len == 0) { /// if it didn't block and there is no data - error
          printf("SDLNet_TCP_Recv: %s\n", SDLNet_GetError());
          break;
        }
        
        /// Try this with std::cout!
        /// The asterisk means that the length of the %s string will be 
        /// specified by the first argument (len). 
        printf("Received: %.*s\n", len, buffer);
        if (buffer[0] == 'q' || buffer[0] == 'Q') {
          printf("Disconecting on a q\n");
          break;
        }
      }
      SDLNet_TCP_Close(client);
    }

    //SDLNet_TCP_Close(tcpsock);
 

  SDLNet_Quit();
  SDL_Quit();
  exit(0);
}