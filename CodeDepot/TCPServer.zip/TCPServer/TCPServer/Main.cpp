#include <SDL3/SDL.h>
#include <SDL_net.h>

#include <thread>
#include <chrono>

#include <cstdio>
#include <cstring>
#include <iostream>

#define BUFFER_SIZE 1024

NET_Server* server;
NET_StreamSocket* socket;

int main(int argc, char* argv[]) {
    bool done = false;
    char data[BUFFER_SIZE];

    if(NET_Init() == false) {
        std::cerr << SDL_GetError() << std::endl;
        exit(EXIT_FAILURE);
    }

    /// Create a "listener" waiting for and in coming connection on port 0x1A2C
    server = NET_CreateServer(nullptr, 0x1A2C,0);
    if(server == nullptr) {
        std::cerr << SDL_GetError() << std::endl;
        NET_Quit();
        exit(EXIT_FAILURE);
    }

    /// Wait for a connection
    std::cout << "Waiting for a connection\n";
    NET_WaitUntilInputAvailable((void**)&server, 1, -1);
    NET_AcceptClient(server, &socket);
    /// I have a connection 
    std::cout << "I have a connection\n";
 
    NET_WaitUntilInputAvailable((void**)&socket, 1, -1);
    NET_ReadFromStreamSocket(socket, data, BUFFER_SIZE);
    std::cout << data << std::endl;

    NET_DestroyServer(server);

    NET_DestroyStreamSocket(socket);
    NET_Quit();
    return 0;
}