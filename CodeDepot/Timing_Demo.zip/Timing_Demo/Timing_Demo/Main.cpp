#include "Timing.h"
#include <vector>

int main() {
	
	/// This keeps the code lines 11-17 within a single scope
	/// When the program reaches } (line 17) the code goes
	/// out of scope and the Timing object will call the destructor
	/// The Timer will then print the deltaTime from 12 -> 16
	
	{   
		Timing timing("std::vector test1");
		std::vector<int> list;
		for (int i = 0; i < 100000; ++i) {
			list.push_back(i);
		}
	}
	/// Do it again but this time 100x more data. 
	/// Does it take 100x as long? Check it out. 
	{
		Timing timing("std::vector test2");
		std::vector<int> list;
		for (int i = 0; i < 100000 * 100; ++i) {
			list.push_back(i);
		}
	}

}
