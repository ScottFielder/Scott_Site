#include <vector>
#include <string> 
#include "MemoryMonitor.h"

void arrayTest();
void stringTest();
void smartPointers();

struct Vec3 {
    float x, y, z;
    Vec3() {
        x = y = z = 0.0f;
    }
    
};

int main(int argc) {
   arrayTest();
   stringTest();
   smartPointers();
    
    std::vector<Vec3> verticies;
    for (int i = 0; i < 32; ++i) {
        verticies.push_back(Vec3());
    }
}

void arrayTest() {
    int* ptr = new int[1024];
    delete[] ptr;
    /// answer should be 4096 bytes
}

void stringTest() {
    //std::string str0;
    std::string str1 = "Game Engines 5";
    std::string str2 = "Game Engines 5: I didn't expect that";
}

/// From Engine 4 class
void smartPointers() {
    std::unique_ptr<Vec3> v = std::make_unique<Vec3>();
}

