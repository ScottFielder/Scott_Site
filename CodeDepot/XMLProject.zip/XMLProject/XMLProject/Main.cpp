
#include <iostream>
#include <fstream>
#include "tinyxml2.h"
using namespace tinyxml2;

struct Color4 {
	float red, green, blue, alpha;
	void print() {
		printf("%f %f %f %f\n", red, green, blue, alpha);
	}
};

void ReadXML(); ///C-style prototype

int main() {
	ReadXML();
}

void ReadXML(){
	XMLDocument doc;
	doc.LoadFile("ColorData.xml");
	bool status = doc.Error();
	if(status) {
		std::cout << doc.ErrorIDToName(doc.ErrorID()) << std::endl;
		return;
	}
	XMLElement *colorDataElement = doc.FirstChildElement("ColorData");
	XMLElement *diffuseElement = colorDataElement->FirstChildElement("Diffuse");
	const char* rText = diffuseElement->FirstChildElement("red")->GetText();
	const char* gText = diffuseElement->FirstChildElement("green")->GetText();
	const char* bText = diffuseElement->FirstChildElement("blue")->GetText();

	Color4 ambient;
	XMLElement* ambientElement = colorDataElement->FirstChildElement("Ambient");
	sscanf_s(diffuseElement->FirstChildElement("red")->GetText(), "%f", &ambient.red);
	sscanf_s(diffuseElement->FirstChildElement("green")->GetText(), "%f", &ambient.green);
	sscanf_s(diffuseElement->FirstChildElement("blue")->GetText(), "%f", &ambient.blue);
	sscanf_s(diffuseElement->FirstChildElement("alpha")->GetText(), "%f", &ambient.alpha);
	ambient.print();

	Color4 specular;
	XMLElement* specularElement = colorDataElement->FirstChildElement("Specular");
	sscanf_s(specularElement->FirstChildElement("red")->GetText(), "%f", &specular.red);
	sscanf_s(specularElement->FirstChildElement("green")->GetText(), "%f", &specular.green);
	sscanf_s(specularElement->FirstChildElement("blue")->GetText(), "%f", &specular.blue);
	sscanf_s(specularElement->FirstChildElement("alpha")->GetText(), "%f", &specular.alpha);
	specular.print();
	
	Color4 diffuse;
	diffuseElement = colorDataElement->FirstChildElement("Diffuse");
	sscanf_s(diffuseElement->FirstChildElement("red")->GetText(), "%f", &diffuse.red);
	sscanf_s(diffuseElement->FirstChildElement("green")->GetText(), "%f", &diffuse.green);
	sscanf_s(diffuseElement->FirstChildElement("blue")->GetText(), "%f", &diffuse.blue);
	sscanf_s(diffuseElement->FirstChildElement("alpha")->GetText(), "%f", &diffuse.alpha);
	diffuse.print();	
}

