#include <winsock2.h>
#include <ws2tcpip.h>
#include <iostream>
#include <string>

/// Only Microsoft allows this but I thought it appropriate to do it this way 
/// since Winsock is exclusively theirs. I'll explain. 
/// We could also put this the properties page of VS. 
#pragma comment(lib, "Ws2_32.lib")
/// Personally, I find this gross - C# loves this idea - grrr



int main(int argc, char **argv) {

    const char* hostname = "a website we will build";
    const char* port = "80"; /// http
    const char* path = "/"; /// root path to the website

    /// Create  Winsock subsystem 
    WSADATA winSock;
    int status; /// Just an error variable

    status = WSAStartup(MAKEWORD(2, 2), &winSock); /// Dare you to figure that out.
    if (status != 0) {
        std::cerr << "WSAStartup failed: " << status << "\n";
        return 1;
    }

    /// Resolve the server address and port. SDL3 does a much better job than Microsoft - duh
    struct addrinfo hints{}; /// remember how I did this in Vulkan? C-code
    struct addrinfo* result = nullptr;
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_protocol = IPPROTO_TCP;

    status = getaddrinfo(hostname, port, &hints, &result);
    if (status != 0) {
        std::cerr << "getaddrinfo failed: " << status << "\n";
        /// We'll need to look this up. I forget. 
        /// I think is just turns off the subsystem. 
        WSACleanup();
        return 1;
    }

    ///  Create a socket to connect to the server 
    SOCKET clientSocket = INVALID_SOCKET;
    clientSocket = socket(result->ai_family, result->ai_socktype, result->ai_protocol);
    if (clientSocket == INVALID_SOCKET) {
        std::cerr << "Error at socket(): " << WSAGetLastError() << "\n";
        freeaddrinfo(result);
        WSACleanup();
        return 1;
    }

    /// Try to connect to the server 
    status = connect(clientSocket, result->ai_addr, static_cast<int>(result->ai_addrlen));
    if (status == SOCKET_ERROR) {
        std::cerr << "connect failed: " << WSAGetLastError() << "\n";
        closesocket(clientSocket);
        clientSocket = INVALID_SOCKET;
        freeaddrinfo(result);
        WSACleanup();
        return 1;
    }
    freeaddrinfo(result);

    /// Form the HTTP request - yes, it has to look this way. 
    /// std::string and be useful sometimes
    std::string request = "GET " + std::string(path) + " HTTP/1.1\r\n"
        "Host: " + std::string(hostname) + "\r\n"
        "Connection: close\r\n"
        "\r\n";

    /// Now send it
    status = send(clientSocket, request.c_str(), static_cast<int>(request.length()), 0);
    if (status == SOCKET_ERROR) {
        std::cerr << "send failed: " << WSAGetLastError() << "\n";
        closesocket(clientSocket);
        WSACleanup();
        return 1;
    }

    // Receive the page data
    const int bufferLength = 4096; /// Limit the data transfer limit
    char recieveBuffer[bufferLength]; /// bufferLength is not really a variable any more it's a const
    do { /// I love do whiles. Very much under used in my opinion 
        status = recv(clientSocket, recieveBuffer, bufferLength, 0);
        if (status > 0) {
            std::cout.write(recieveBuffer, status);
        }
        else if (status == 0) {
            /// if the socket connection closed... 
            std::cout << "Connection closed\n";
        }
        else {
            std::cerr << "Didn't read the data: " << WSAGetLastError() << "\n";
        }
    } while (status > 0);

    /// destroy everything,  no memory leaks
    closesocket(clientSocket);
    WSACleanup();

    return 0;
}
