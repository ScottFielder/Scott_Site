#include <iostream>
#include <string.h>
#include <sstream>
#include <SDL3/SDL.h>
#include <SDL3/SDL_net.h>

void Client(); /// Prototyping 

int main(int argc, char*argv[]){
	Client();
	return 1;
}

void Client(){
	NET_DatagramSocket *sd;
	NET_Address *srvadd;
	NET_Datagram *p=nullptr;
	bool isRunning;
	std::string data; 
	
	/// Initialize SDL_net subsystem
	if (NET_Init() < 0) {
		std::cerr << SDL_GetError() << std::endl;
		exit(EXIT_FAILURE);
	}
 
	/// Open a socket and bind the port to the OS
	if(!(sd = NET_CreateDatagramSocket(NULL, 0x1A1B))) {
		std::cerr << SDL_GetError() << std::endl;
		exit(EXIT_FAILURE);
	}
	
 
	/// Resolve server name 
	srvadd = NET_ResolveHostname("127.0.0.1");
	if (srvadd == NULL) {
		std::cerr << SDL_GetError() << std::endl;
		exit(EXIT_FAILURE);
	}

	//std::cout << std::hex << srvadd.host << " " << srvadd.port <<  std::endl;
	/// Allocate memory for the packet 
	p = (NET_Datagram*)malloc(sizeof(NET_Datagram));
	p->port = 0x1A2B;
	p->buf = (Uint8*)malloc(512);

	
	
 
	///Main loop
	isRunning = true;
	std::string str;
	while (isRunning){
		std::cout << "Write something: ";
		std::cin >> str;
		std::cout << std::endl;
		int len = str.length() + 1;

		//..std::cout << srvadd.port << std::endl; /// Write to port number 
		p->addr = srvadd;	/// Set the destination host
		p->port = 0x1A2B;	/// and destination port 
		p->buflen = len;
		strcpy_s( (char*)p->buf,len, str.c_str());
		
		NET_SendDatagram(sd, srvadd, p->port, p->buf, p->buflen); /// This sets the p->channel to -1 and send the data
 
		/// Quit if packet contains "quit" 
		if (strcmp((char *)p->buf, "quit") == 0){
			isRunning = false;
		}
	}
 
	NET_DestroyDatagram(p);
	NET_Quit();
 
	return;
}


