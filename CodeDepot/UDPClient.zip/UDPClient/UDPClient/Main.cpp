#include <iostream>
#include <string.h>
#include <sstream>
#include <SDL_net.h>

void Client(); /// C-style prototyping 

int main(int argc, char*argv[]){
	Client();
	return 0;
}

void Client(){
	UDPsocket sd{};
	IPaddress srvadd{};
	UDPpacket *p=nullptr;
	bool isRunning;
	std::string data; 
	
	/// Initialize SDL_net subsystem
	if (SDLNet_Init() < 0) {
		std::cerr << SDLNet_GetError() << std::endl;
		exit(EXIT_FAILURE);
	}
 
	
	if (!(sd = SDLNet_UDP_Open(0))){
		std::cerr << SDLNet_GetError() << std::endl;
		exit(EXIT_FAILURE);
	}
 
	/// Resolve server name 
	if (SDLNet_ResolveHost(&srvadd, "127.0.0.1", 0x1A2B) == -1) {
		std::cerr << SDLNet_GetError() << std::endl;
		exit(EXIT_FAILURE);
	}

	std::cout << std::hex << srvadd.host << " " << srvadd.port <<  std::endl;
	/// Allocate memory for the packet 
	if (!(p = SDLNet_AllocPacket(512))){
		std::cerr << SDLNet_GetError() << std::endl;
		exit(EXIT_FAILURE);
	}

	/// Allocate memory for the packet 
	/// I made it just a big size. If you what data you are sending, you could make it that size
	if (!(p = SDLNet_AllocPacket(512))){
		std::cerr << SDLNet_GetError() << std::endl;
		exit(EXIT_FAILURE);
	}
 
	///Main loop
	isRunning = true;
	std::string str;
	while (isRunning){
		std::cout << "Write something: ";
		std::cin >> str;
		std::cout << std::endl;
		int len = str.length() + 1;

		std::cout << srvadd.port << std::endl; /// Write to port number 
		p->address.host = srvadd.host;	/// Set the destination host
		p->address.port = srvadd.port;	/// and destination port 
		p->len = len;
		strcpy_s( (char*)p->data,len, str.c_str());
		
		SDLNet_UDP_Send(sd, -1, p); /// This sets the p->channel to -1 and send the data
 
		/// Quit if packet contains "quit" 
		if (strcmp((char *)p->data, "quit") == 0){
			isRunning = false;
		}
	}
 
	SDLNet_FreePacket(p);
	SDLNet_Quit();
 
	return;
}


