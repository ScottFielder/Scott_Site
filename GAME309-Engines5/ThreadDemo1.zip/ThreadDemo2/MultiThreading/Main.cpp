
#include <iostream>
#include <thread>
#include <chrono>

/// Prototype the function 
void downloadSomething(const char* url);

/// A callable object, a functor
class Threadable_Obj {
public:
	void operator()(int x) {

		for (int i = 0; i < x; i++) {
			std::this_thread::sleep_for(std::chrono::milliseconds(50));
			std::cout << "O";
		}
	}
};


int main() {
	/// This thread is launched by using a function
	std::thread th1(downloadSomething, "www.google.com");

	/// This thread is launched by using a functor
	std::thread th2(Threadable_Obj(), 200);

	/// Define a Lambda Expression
	auto f = [](int x) {
		std::cout << "Thread using lambda\n";
		for (int i = 0; i < x; i++) {
			std::this_thread::sleep_for(std::chrono::milliseconds(50));
			std::cout << "l";
		}
		std::cout << "\n";
	};

	// This thread is launched by using a lamda expression 
	std::thread th3(f, 300);

	
	th1.detach();	
	th2.detach();
	th3.detach();

	for(int j = 0; j < 100; ++ j){
		std::this_thread::sleep_for(std::chrono::milliseconds(50));
		std::cout << "m";
	}
	std::cout << "\n";

	return 0;
}



/// A Single Function (prototyped on line 7) 
void downloadSomething(const char* url) {
	printf("Downloading %s",url);
	for (int i = 0; i < 80; i++) {
		std::this_thread::sleep_for(std::chrono::milliseconds(50));
		std::cout << ".";
	}
	std::cout << "\n";
}

